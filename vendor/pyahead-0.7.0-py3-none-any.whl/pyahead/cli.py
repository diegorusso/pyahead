"""Command-line interface for static analysis and registry inspection."""

import os
import sys
from argparse import ArgumentParser, BooleanOptionalAction, Namespace
from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TypeVar, cast

from pyahead import __version__
from pyahead._human_text import SafeArgumentParser, escape_terminal_text
from pyahead.analysis import FileProgress, ScanRequest, scan
from pyahead.analysis.discovery import DiscoveryError
from pyahead.baseline import render_baseline
from pyahead.config import resolve_project_root
from pyahead.dependencies import (
    DependencyReport,
    collect_dependency_report,
    load_dependency_configuration,
    render_dependency_json,
    render_dependency_text,
)
from pyahead.evidence import merge_evidence, resolve_source_commit
from pyahead.model import (
    ConfigurationError,
    ExitCode,
    PerFileIgnore,
    Registry,
    ScanReport,
)
from pyahead.output import OutputError, write_text_atomic
from pyahead.registry import RegistryError, load_registry, validate_registry
from pyahead.registry.presentation import (
    render_registry_coverage,
    render_registry_list,
    render_rule_explanation,
)
from pyahead.reporting import (
    render_json,
    render_quiet_text,
    render_sarif,
    render_text,
)
from pyahead.versions import InvalidPythonMinorError

_T = TypeVar("_T")


def _registry_source_options(parser: ArgumentParser) -> None:
    parser.add_argument(
        "registry_path",
        nargs="?",
        type=Path,
        metavar="PATH",
        help="registry directory or index YAML (defaults to bundled data)",
    )
    parser.add_argument(
        "--registry",
        type=Path,
        dest="registry_option",
        metavar="PATH",
        help="registry directory or index YAML (alternative to PATH)",
    )


def _scan_options(
    parser: ArgumentParser,
    *,
    include_report_output: bool,
) -> None:
    parser.add_argument("paths", nargs="*", type=Path, metavar="PATH")
    parser.add_argument(
        "--baseline-python",
        metavar="VERSION",
        help="oldest supported Python minor, such as 3.11",
    )
    parser.add_argument(
        "--horizon-python",
        metavar="VERSION",
        help="latest Python minor to forecast, such as 3.15",
    )
    parser.add_argument(
        "--config",
        type=Path,
        metavar="PATH",
        help="strict TOML configuration beneath the selected root",
    )
    parser.add_argument(
        "--root",
        type=Path,
        metavar="PATH",
        help="project root (otherwise inferred from the current directory)",
    )
    parser.add_argument(
        "--registry",
        type=Path,
        metavar="PATH",
        help="registry directory or index YAML (defaults to bundled data)",
    )
    parser.add_argument(
        "--include",
        action="append",
        default=None,
        metavar="PATTERN",
        help="replace configured include patterns (repeatable)",
    )
    parser.add_argument(
        "--exclude",
        action="append",
        default=None,
        metavar="PATTERN",
        help="replace configured exclude patterns (repeatable)",
    )
    parser.add_argument(
        "--source-root",
        action="append",
        default=None,
        dest="source_roots",
        metavar="PATH",
        help="replace configured import source roots (repeatable)",
    )
    parser.add_argument(
        "--respect-gitignore",
        action=BooleanOptionalAction,
        default=None,
        help="respect hierarchical .gitignore rules (default: true)",
    )
    parser.add_argument(
        "--minimum-confidence",
        choices=("high", "medium"),
        default=None,
    )
    parser.add_argument(
        "--fail-on",
        choices=("never", "breaking", "risk", "deprecated", "any"),
        default=None,
    )
    parser.add_argument(
        "--show-unscheduled",
        action=BooleanOptionalAction,
        default=None,
    )
    parser.add_argument(
        "--max-file-size-bytes",
        type=int,
        default=None,
        metavar="BYTES",
    )
    parser.add_argument(
        "--per-file-ignore",
        action="append",
        default=[],
        metavar="PATTERN=RULE_ID[,RULE_ID]",
        help="add rule-specific ignores for one path pattern",
    )
    parser.add_argument(
        "--show-suppressed",
        action="store_true",
        help="retain suppressed findings in reports",
    )
    parser.add_argument(
        "--allow-incomplete",
        action="store_true",
        help="retain incomplete diagnostics without forcing exit code 3",
    )
    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument("--verbose", action="store_true")
    verbosity.add_argument("--quiet", action="store_true")
    if include_report_output:
        parser.add_argument(
            "--format",
            choices=("text", "json", "sarif"),
            default="text",
            dest="output_format",
        )
        parser.add_argument(
            "--output",
            type=Path,
            metavar="PATH",
            help="write complete output atomically; use - for stdout",
        )
        parser.add_argument(
            "--baseline-file",
            type=Path,
            metavar="PATH",
            help="baseline beneath the selected root (relative paths use the root)",
        )
        parser.add_argument("--fail-new-only", action="store_true")
        parser.add_argument(
            "--evidence",
            action="append",
            default=[],
            type=Path,
            metavar="PATH",
            help="ingest versioned user-CI warning evidence (repeatable)",
        )
        parser.add_argument(
            "--source-commit",
            metavar="SHA",
            help=(
                "full scanned commit for evidence freshness checks; CI environment "
                "variables are used when omitted"
            ),
        )


def _build_parser() -> ArgumentParser:
    """Create the command-line parser."""
    parser = SafeArgumentParser(prog="pyahead")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("version", help="show the installed version")

    check = subparsers.add_parser("check", help="scan Python source")
    _scan_options(check, include_report_output=True)

    dependencies = subparsers.add_parser(
        "dependencies",
        help="inspect opt-in dependency compatibility evidence",
    )
    dependencies.add_argument(
        "--root",
        type=Path,
        metavar="PATH",
        help="project root (otherwise inferred from the current directory)",
    )
    dependencies.add_argument(
        "--config",
        type=Path,
        metavar="PATH",
        help="configuration containing [tool.pyahead.dependencies]",
    )
    dependencies.add_argument(
        "--network",
        action=BooleanOptionalAction,
        default=None,
        help="explicitly enable or disable resolver network access",
    )
    dependencies.add_argument(
        "--resolve",
        action=BooleanOptionalAction,
        default=None,
        help="explicitly enable or disable the isolated resolver",
    )
    dependencies.add_argument(
        "--timeout-seconds",
        type=float,
        default=None,
        metavar="SECONDS",
        help="finite positive deadline for each resolver process",
    )
    dependencies.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        dest="output_format",
    )
    dependencies.add_argument(
        "--output",
        type=Path,
        metavar="PATH",
        help="write complete output atomically; use - for stdout",
    )

    baseline = subparsers.add_parser(
        "baseline", help="create deterministic finding baselines"
    )
    baseline.set_defaults(command_parser=baseline)
    baseline_subparsers = baseline.add_subparsers(dest="baseline_command")
    baseline_create = baseline_subparsers.add_parser(
        "create", help="scan and create a baseline"
    )
    _scan_options(baseline_create, include_report_output=False)
    baseline_create.add_argument(
        "--output",
        type=Path,
        default=Path(".pyahead-baseline.json"),
        metavar="PATH",
        help="destination beneath the selected root (relative paths use the root)",
    )

    registry = subparsers.add_parser("registry", help="inspect registry data")
    registry.set_defaults(command_parser=registry)
    registry_subparsers = registry.add_subparsers(dest="registry_command")
    registry_validate = registry_subparsers.add_parser(
        "validate", help="validate every registry file"
    )
    _registry_source_options(registry_validate)
    registry_list = registry_subparsers.add_parser(
        "list", help="list canonical registry rules"
    )
    _registry_source_options(registry_list)
    registry_coverage = registry_subparsers.add_parser(
        "coverage", help="report authoritative-source coverage"
    )
    _registry_source_options(registry_coverage)

    explain = subparsers.add_parser("explain", help="explain one registry rule")
    explain.add_argument("rule_id", metavar="RULE_ID")
    explain.add_argument(
        "--registry",
        type=Path,
        metavar="PATH",
        help="registry directory or index YAML (defaults to bundled data)",
    )
    return parser


def _per_file_ignores(values: list[str]) -> tuple[PerFileIgnore, ...]:
    parsed: list[PerFileIgnore] = []
    for value in values:
        pattern, separator, identifiers = value.partition("=")
        rule_ids = tuple(
            dict.fromkeys(
                identifier.strip()
                for identifier in identifiers.split(",")
                if identifier.strip()
            )
        )
        if not separator or not pattern or not rule_ids:
            message = "--per-file-ignore must use PATTERN=RULE_ID[,RULE_ID]"
            raise ConfigurationError(message)
        parsed.append(PerFileIgnore(pattern=pattern, rule_ids=rule_ids))
    return tuple(parsed)


def _scan_request(arguments: Namespace) -> ScanRequest:
    root = resolve_project_root(Path.cwd(), arguments.root)
    current = Path.cwd()
    paths = tuple(
        path if path.is_absolute() else current / path for path in arguments.paths
    )
    return ScanRequest(
        root=root,
        baseline_python=arguments.baseline_python,
        horizon_python=arguments.horizon_python,
        paths=paths,
        registry_source=arguments.registry,
        config_path=arguments.config,
        include=(tuple(arguments.include) if arguments.include is not None else None),
        exclude=(tuple(arguments.exclude) if arguments.exclude is not None else None),
        source_roots=(
            tuple(arguments.source_roots)
            if arguments.source_roots is not None
            else None
        ),
        respect_gitignore=arguments.respect_gitignore,
        minimum_confidence=arguments.minimum_confidence,
        fail_on=getattr(arguments, "fail_on", None),
        show_unscheduled=arguments.show_unscheduled,
        max_file_size_bytes=arguments.max_file_size_bytes,
        per_file_ignores=_per_file_ignores(arguments.per_file_ignore),
        baseline_file=getattr(arguments, "baseline_file", None),
        fail_new_only=getattr(arguments, "fail_new_only", False),
        show_suppressed=arguments.show_suppressed,
        allow_incomplete=arguments.allow_incomplete,
    )


def _write_verbose_configuration(report: ScanReport) -> None:
    configuration = report.configuration
    per_file_ignore_entries = []
    for item in configuration.per_file_ignores:
        pattern = escape_terminal_text(item.pattern)
        rule_ids = [escape_terminal_text(rule_id) for rule_id in item.rule_ids]
        per_file_ignore_entries.append(f"{pattern!r}: {rule_ids!r}")
    per_file_ignores = "{" + ", ".join(per_file_ignore_entries) + "}"
    include = [escape_terminal_text(value) for value in configuration.include]
    exclude = [escape_terminal_text(value) for value in configuration.exclude]
    source_roots = [escape_terminal_text(value) for value in configuration.source_roots]
    sys.stderr.write(
        "pyahead: configuration: "
        f"baseline={report.policy.baseline_python} "
        f"({escape_terminal_text(report.policy_provenance.baseline_python)}); "
        f"horizon={report.policy.horizon_python} "
        f"({escape_terminal_text(report.policy_provenance.horizon_python)}); "
        f"include={include!r}; "
        f"exclude={exclude!r}; "
        f"source-roots={source_roots!r} "
        f"({escape_terminal_text(configuration.source_roots_provenance)}); "
        f"minimum-confidence={configuration.minimum_confidence.value}; "
        f"fail-on={configuration.fail_on.value}; "
        f"respect-gitignore={str(configuration.respect_gitignore).lower()}; "
        f"show-unscheduled={str(configuration.show_unscheduled).lower()}; "
        f"max-file-size-bytes={configuration.max_file_size_bytes}; "
        f"per-file-ignores={per_file_ignores}; "
        f"fail-new-only={str(configuration.fail_new_only).lower()}; "
        f"show-suppressed={str(configuration.show_suppressed).lower()}; "
        f"allow-incomplete={str(configuration.allow_incomplete).lower()}\n"
    )


def _write_scan_diagnostics(report: ScanReport) -> None:
    """Write baseline-scan diagnostics without contaminating baseline JSON."""
    for diagnostic in report.diagnostics:
        if diagnostic.location is None:
            location = ""
        else:
            start = diagnostic.location.region.start
            location = (
                f" {escape_terminal_text(diagnostic.location.path.as_posix())}:"
                f"{start.line}:{start.column}"
            )
        incomplete = " [incomplete analysis]" if diagnostic.incomplete else ""
        sys.stderr.write(
            f"pyahead: {escape_terminal_text(diagnostic.code)}{location}: "
            f"{escape_terminal_text(diagnostic.message)}{incomplete}\n"
        )


def _write_error(error: BaseException) -> None:
    """Write one terminal-safe expected CLI error."""
    sys.stderr.write(f"pyahead: error: {escape_terminal_text(str(error))}\n")


def _write_output(
    rendered: str,
    output: Path | None,
    *,
    root: Path | None = None,
) -> None:
    if output is None or output == Path("-"):
        sys.stdout.write(rendered)
        return
    selected = output if output.is_absolute() else Path.cwd() / output
    write_text_atomic(selected, rendered, root=root)


def _root_bounded_output_path(
    output: Path | None,
    root: Path,
    *,
    label: str,
) -> Path | None:
    """Resolve an optional destination beneath the selected project root."""
    if output is None or output == Path("-"):
        return output
    selected = output if output.is_absolute() else root / output
    try:
        logical_path = Path(os.path.abspath(selected))  # noqa: PTH100
        logical_path.relative_to(root)
        logical_path.resolve().relative_to(root)
    except (OSError, RuntimeError, ValueError) as error:
        message = f"{label} output must remain beneath the project root"
        raise OutputError(message) from error
    return logical_path


def _render_check(arguments: Namespace, report: ScanReport) -> str:
    if arguments.output_format == "json":
        return render_json(report)
    if arguments.output_format == "sarif":
        return render_sarif(report)
    if arguments.quiet:
        return render_quiet_text(report)
    return render_text(report)


def _validate_evidence_arguments(arguments: Namespace) -> None:
    if arguments.evidence and arguments.output_format == "sarif":
        message = "--evidence reporting is supported with text or JSON, not SARIF"
        raise ConfigurationError(message)
    if arguments.source_commit is not None and not arguments.evidence:
        message = "--source-commit requires --evidence"
        raise ConfigurationError(message)


@dataclass(frozen=True)
class _Failed:
    """A command that ended in an expected or internal error."""

    code: int


_SCAN_INPUT_ERRORS: tuple[type[Exception], ...] = (
    ConfigurationError,
    DiscoveryError,
    InvalidPythonMinorError,
    OutputError,
    RegistryError,
)


def _guarded(
    work: Callable[[], _T],
    invalid_input: tuple[type[Exception], ...],
) -> _T | _Failed:
    """Run one command's work, mapping failures to the CLI's exit codes.

    An ``invalid_input`` error is reported as exit 2; anything else is the
    reserved internal error, exit 4. Output the command writes afterwards
    stays outside, so a closed pipe is not mistaken for an internal error.
    """
    try:
        return work()
    except invalid_input as error:
        _write_error(error)
        return _Failed(int(ExitCode.INVALID_INPUT))
    except Exception:  # noqa: BLE001 - the CLI contract reserves exit code 4.
        sys.stderr.write("pyahead: PYA9000: unexpected internal error\n")
        return _Failed(int(ExitCode.INTERNAL_ERROR))


def _check(
    arguments: Namespace,
    on_file: Callable[[FileProgress], None] | None,
) -> ScanReport:
    _validate_evidence_arguments(arguments)
    request = replace(_scan_request(arguments), on_file=on_file)
    report = scan(request)
    if arguments.evidence:
        report = merge_evidence(
            report,
            arguments.evidence,
            root=request.root,
            source_commit=resolve_source_commit(arguments.source_commit),
        )
    rendered = _render_check(arguments, report)
    _write_output(
        rendered,
        _root_bounded_output_path(arguments.output, request.root, label="report"),
        root=request.root,
    )
    if arguments.output_format == "text" and arguments.quiet:
        _write_scan_diagnostics(report)
    return report


def _run_check(
    arguments: Namespace,
    on_file: Callable[[FileProgress], None] | None = None,
) -> int:
    outcome = _guarded(lambda: _check(arguments, on_file), _SCAN_INPUT_ERRORS)
    if isinstance(outcome, _Failed):
        return outcome.code
    if arguments.verbose:
        _write_verbose_configuration(outcome)
    return int(outcome.exit_code)


def _create_baseline(arguments: Namespace) -> ScanReport | int:
    request = _scan_request(arguments)
    report = scan(request)
    _write_scan_diagnostics(report)
    if report.counts.files_incomplete and not report.configuration.allow_incomplete:
        sys.stderr.write(
            "pyahead: error: refusing to create a baseline from an incomplete scan\n"
        )
        return int(ExitCode.INCOMPLETE)
    if report.counts.files_incomplete:
        sys.stderr.write(
            "pyahead: warning: source scan is incomplete; baseline contains "
            "only findings from analyzed files\n"
        )
    _write_output(
        render_baseline(report),
        _root_bounded_output_path(arguments.output, request.root, label="baseline"),
        root=request.root,
    )
    return report


def _run_baseline_create(arguments: Namespace) -> int:
    outcome = _guarded(lambda: _create_baseline(arguments), _SCAN_INPUT_ERRORS)
    if isinstance(outcome, _Failed):
        return outcome.code
    if isinstance(outcome, int):
        return outcome
    if arguments.verbose:
        _write_verbose_configuration(outcome)
    return int(ExitCode.SUCCESS)


def _dependency_report(arguments: Namespace) -> DependencyReport:
    root = resolve_project_root(Path.cwd(), arguments.root)
    configuration = load_dependency_configuration(
        root,
        arguments.config,
        network_override=arguments.network,
        resolve_override=arguments.resolve,
        timeout_override=arguments.timeout_seconds,
    )
    report = collect_dependency_report(configuration, root=root)
    rendered = (
        render_dependency_json(report)
        if arguments.output_format == "json"
        else render_dependency_text(report)
    )
    _write_output(
        rendered,
        _root_bounded_output_path(arguments.output, root, label="dependency report"),
        root=root,
    )
    return report


def _run_dependencies(arguments: Namespace) -> int:
    outcome = _guarded(
        lambda: _dependency_report(arguments), (ConfigurationError, OutputError)
    )
    return outcome.code if isinstance(outcome, _Failed) else int(outcome.exit_code)


def _selected_registry_source(arguments: Namespace) -> Path | None:
    path = cast("Path | None", arguments.registry_path)
    option = cast("Path | None", arguments.registry_option)
    if path is not None and option is not None:
        message = "provide a registry as PATH or --registry, not both"
        raise RegistryError(message)
    return option if option is not None else path


def _render_registry_coverage(registry: Registry) -> str:
    if not registry.coverage:
        message = "registry declares no authoritative-source coverage manifests"
        raise RegistryError(message)
    return render_registry_coverage(registry)


def _registry_text(arguments: Namespace) -> str:
    source = _selected_registry_source(arguments)
    if arguments.registry_command == "validate":
        registry = validate_registry(source)
        noun = "rule" if len(registry.rules) == 1 else "rules"
        return (
            f"Registry {escape_terminal_text(registry.release)} "
            f"({escape_terminal_text(registry.revision[:12])}): "
            f"{len(registry.rules)} {noun} valid.\n"
        )
    registry = load_registry(source)
    if arguments.registry_command == "list":
        return render_registry_list(registry)
    return _render_registry_coverage(registry)


def _run_registry(arguments: Namespace) -> int:
    if arguments.registry_command not in {"validate", "list", "coverage"}:
        return int(ExitCode.INTERNAL_ERROR)
    outcome = _guarded(lambda: _registry_text(arguments), (RegistryError,))
    if isinstance(outcome, _Failed):
        return outcome.code
    sys.stdout.write(outcome)
    return int(ExitCode.SUCCESS)


def _explanation(arguments: Namespace) -> str | None:
    registry = load_registry(arguments.registry)
    rule = registry.find_rule(arguments.rule_id)
    return None if rule is None else render_rule_explanation(registry, rule)


def _run_explain(arguments: Namespace) -> int:
    outcome = _guarded(lambda: _explanation(arguments), (RegistryError,))
    if isinstance(outcome, _Failed):
        return outcome.code
    if outcome is None:
        rule_id = escape_terminal_text(arguments.rule_id)
        sys.stderr.write(f"pyahead: error: unknown registry rule ID {rule_id!r}\n")
        return int(ExitCode.INVALID_INPUT)
    sys.stdout.write(outcome)
    return int(ExitCode.SUCCESS)


def main(
    argv: list[str] | None = None,
    *,
    on_file: Callable[[FileProgress], None] | None = None,
) -> int:
    """Run the command-line interface and return its stable exit code.

    ``on_file`` is for a caller that embeds the CLI, such as the browser page:
    ``check`` passes it through as ``ScanRequest.on_file`` so the caller can
    show progress. No command-line option sets it.
    """
    parser = _build_parser()
    arguments = parser.parse_args(argv)
    if arguments.command == "check":
        result = _run_check(arguments, on_file)
    elif arguments.command == "dependencies":
        result = _run_dependencies(arguments)
    elif arguments.command == "baseline":
        if arguments.baseline_command is None:
            arguments.command_parser.print_help()
            result = int(ExitCode.SUCCESS)
        else:
            result = _run_baseline_create(arguments)
    elif arguments.command == "explain":
        result = _run_explain(arguments)
    elif arguments.command == "registry":
        if arguments.registry_command is None:
            arguments.command_parser.print_help()
            result = int(ExitCode.SUCCESS)
        else:
            result = _run_registry(arguments)
    elif arguments.command == "version":
        sys.stdout.write(f"pyahead {__version__}\n")
        result = int(ExitCode.SUCCESS)
    elif arguments.command is None:
        parser.print_help()
        result = int(ExitCode.SUCCESS)
    else:
        result = int(ExitCode.INTERNAL_ERROR)
    return result
