"""Python minor-version values used by policy and registry models."""

import re
from dataclasses import dataclass
from typing import Self

# A three-digit minor leaves ample release headroom while keeping conversion
# bounded for untrusted policy and registry input.
PYTHON_MINOR_PATTERN = r"3\.(0|[1-9][0-9]{0,2})"
_PYTHON_MINOR_RE = re.compile(f"{PYTHON_MINOR_PATTERN}\\Z")
_SUPPORTED_MAJOR = 3


class InvalidPythonMinorError(ValueError):
    """Raised when a policy value is not a supported Python minor string."""

    def __init__(self, value: object) -> None:
        """Describe the invalid value without attempting to normalize it."""
        super().__init__(f"expected a Python minor such as '3.13', got {value!r}")


@dataclass(frozen=True, order=True)
class PythonMinor:
    """A canonical Python 3 minor version."""

    major: int
    minor: int

    def __post_init__(self) -> None:
        """Reject values outside the initial Python 3 minor model."""
        if self.major != _SUPPORTED_MAJOR or self.minor < 0:
            value = f"{self.major}.{self.minor}"
            raise InvalidPythonMinorError(value)

    @classmethod
    def parse(cls, value: str) -> Self:
        """Parse a strict ``MAJOR.MINOR`` policy value."""
        match = _PYTHON_MINOR_RE.fullmatch(value)
        if match is None:
            raise InvalidPythonMinorError(value)
        return cls(major=_SUPPORTED_MAJOR, minor=int(match.group(1)))

    def __str__(self) -> str:
        """Render the canonical minor version."""
        return f"{self.major}.{self.minor}"


def target_set(
    baseline: PythonMinor,
    horizon: PythonMinor,
) -> frozenset[PythonMinor]:
    """Generate an inclusive set of Python minor targets."""
    if horizon < baseline:
        message = "horizon Python must not precede baseline Python"
        raise ValueError(message)
    return frozenset(
        PythonMinor(major=baseline.major, minor=minor)
        for minor in range(baseline.minor, horizon.minor + 1)
    )
