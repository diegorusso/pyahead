"""Bundled compatibility registry snapshot."""
